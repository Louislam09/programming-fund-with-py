num1 = input('Escribe un numero: ')
num2 = input('Escribe otro numero: ')

resultado_de_la_suma = int(num1) + int(num2)

print("La suma de los dos numeros es igual a: {0}".format(resultado_de_la_suma))
