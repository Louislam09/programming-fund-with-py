from os import system

num1 = input('Escriba el primer numero: ')
num2 = input('Escriba el segundo numero: ')

suma = int(num1) + int(num2)

print(f"La suma de los numeros es: {suma}")
